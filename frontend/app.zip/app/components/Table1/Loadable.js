/**
 *
 * Asynchronously loads the component for Table1
 *
 */

import loadable from "utils/loadable";

export default loadable(() => import("./index"));
