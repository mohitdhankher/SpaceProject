/**
 *
 * Asynchronously loads the component for FilterSpacLanding
 *
 */

import loadable from "utils/loadable";

export default loadable(() => import("./index"));
