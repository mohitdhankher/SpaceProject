import styled from 'styled-components';

export default styled.div`
  width: 100%;
  font-size: 15px;
  font-family: 'MarsCentra-Book';
`;