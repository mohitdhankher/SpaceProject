/**
 *
 * Asynchronously loads the component for DropView1
 *
 */

import loadable from "utils/loadable";

export default loadable(() => import("./index"));
