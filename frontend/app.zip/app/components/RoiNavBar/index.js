/**
 *
 * RoiNavBar
 *
 */

import React, { memo } from "react";
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

import { FormattedMessage } from "react-intl";
import messages from "./messages";
import logo from '../../images/mars.png';
import {Link, NavLink} from "react-router-dom";
import ListItemText from "@material-ui/core/ListItemText";
import Grid from "@material-ui/core/Grid";
import Box from "@material-ui/core/Box";
import './style.css'
import IconButton from "@material-ui/core/IconButton";
import Toolbar from "@material-ui/core/Toolbar";
import HomeIcon from "@material-ui/icons/Home";
import mu from "../../images/circle.png";
import AppBar from "@material-ui/core/AppBar";
import ListItem from "@material-ui/core/ListItem";
import { Layout, Menu, Breadcrumb } from 'antd';
import imgM from "../../images/mm2.png";
import Button from "@material-ui/core/Button";

const { Header, Content, Footer } = Layout;




function RoiNavBar(props) {
    const isActive = (path, match, location) => !!(match || path === location.pathname);
    let arrayyear = ['2006','2007','2008','2009','2010','2011','2012','2013','2014','2015','2016','2017','2018','2019']
    let filteryear = (e)=>{
        debugger
        props.filteryear(e);
    }
    let fromNotifications,LandfromNotifications
    return (
        <Grid container justify={"space-evenly"}>
        <nav className="navColor">
            <Grid>
                Filter
            </Grid>
            <Grid>
                Launch Year
            </Grid>
            <Grid container className="button">
                { arrayyear.map(function(name, index){
                    return <Grid lg={5}> <NavLink exact  to={{
                        pathname: "spac",
                        state: {
                            fromNotifications: true
                        }
                    }
                    }
                                                  className="alignHome" activeClassName="active" >
                        <Button className="buttoncolor" onClick={filteryear} key={ index }> {name} </Button>
                    </NavLink></Grid>
                })}

                <Grid>
                    Successful Launch
                </Grid>


            </Grid>
            <Grid container>
                <Grid lg={5}>
                    <NavLink exact  to={{
                        pathname: "LaunchSuccess",
                        state: {
                            fromNotifications: true
                        }
                    }
                    }
                             className="alignHome" activeClassName="active" >
                        <Button className="buttoncolor"> True </Button>
                    </NavLink>
                </Grid>
                <Grid lg={5}>
                    <NavLink exact  to={{
                        pathname: "LaunchSuccess",
                        state: {
                            fromNotifications: false
                        }
                    }
                    }
                             className="alignHome" activeClassName="active" >
                        <Button className="buttoncolor"> False </Button>
                    </NavLink>
                </Grid>
            </Grid>
            <Grid>
                Landing Succesful
            </Grid>
            <Grid container>
                <Grid lg={5}>
                    <NavLink exact  to={{
                        pathname: "LandingSuccess",
                        state: {
                            LandfromNotifications: true
                        }
                    }
                    }
                             className="alignHome" activeClassName="active" >
                        <Button className="buttoncolor"> True </Button>
                    </NavLink>
                </Grid>
                <Grid lg={5}>
                    <NavLink exact  to={{
                        pathname: "LandingSuccess",
                        state: {
                            LandfromNotifications: false
                        }
                    }
                    }
                             className="alignHome" activeClassName="active" >
                        <Button className="buttoncolor"> False </Button>
                    </NavLink>
                </Grid>
            </Grid>
                {/*<Grid container>*/}
                {/*<Grid lg={11}>*/}
                    {/*<a href="#"><img src={mu} alt='mu' width={50} height={50}/></a>*/}
                    {/*<a href="#"><img src={logo} alt='logo' width={120} height={50}/></a>*/}


                    {/*<NavLink exact to="/" className="alignHome" activeClassName="active">Home</NavLink>*/}
                    {/*<NavLink exact to="/reporting" className="alignHome" activeClassName="active">Reporting</NavLink>*/}
                    {/*<NavLink exact to="/simulation" className="alignElastic" activeClassName="active">Simulation</NavLink>*/}
                    {/*<NavLink exact to="/scenario" className="alignGap" activeClassName="active">Scenario List</NavLink>*/}







            {/*</Grid>*/}
            {/*<Grid lg={1}>*/}
            {/*    <a href="#"><img src={imgM} alt='imgM' width={80} height={50} className="alignLogo"/></a>*/}
            {/*</Grid></Grid>*/}
            </nav>

        </Grid>
    )
}

RoiNavBar.propTypes = {};

export default memo(RoiNavBar);