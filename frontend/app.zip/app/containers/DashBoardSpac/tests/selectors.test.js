// import { selectDashBoardSpacDomain } from '../selectors';

describe("selectDashBoardSpacDomain", () => {
  it("Expect to have unit tests specified", () => {
    expect(true).toEqual(false);
  });
});
