/*
 *
 * DashBoardSpac constants
 *
 */

export const DEFAULT_ACTION = "app/DashBoardSpac/DEFAULT_ACTION";
export const SpaceXdataConst = "app/DashBoardSpac/SpaceXdataConst";
export const SaveSpaceXdataConst = "app/DashBoardSpac/SaveSpaceXdataConst";