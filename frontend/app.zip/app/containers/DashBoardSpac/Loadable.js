/**
 *
 * Asynchronously loads the component for DashBoardSpac
 *
 */

import loadable from "utils/loadable";

export default loadable(() => import("./index"));
