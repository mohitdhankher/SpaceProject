/*
 *
 * ComparePage constants
 *
 */

export const DEFAULT_ACTION = "app/ComparePage/DEFAULT_ACTION";
