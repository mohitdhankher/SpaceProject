/*
 *
 * DashBoardLaunchSuccess constants
 *
 */

export const DEFAULT_ACTION = "app/DashBoardLaunchSuccess/DEFAULT_ACTION";
