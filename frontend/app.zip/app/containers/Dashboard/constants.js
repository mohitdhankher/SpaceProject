/*
 *
 * Dashboard constants
 *
 */

export const DEFAULT_ACTION = "app/Dashboard/DEFAULT_ACTION";


export const SAVE_GRAPH_DATA = "app/Dashboard/SAVE_GRAPH_DATA";