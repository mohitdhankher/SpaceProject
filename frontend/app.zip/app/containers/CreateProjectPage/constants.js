/*
 *
 * CreateProjectPage constants
 *
 */

export const DEFAULT_ACTION = "app/CreateProjectPage/DEFAULT_ACTION";

export const CREATE_PROJECT = "app/CreateProjectPage/CREATE_PROJECT";
export const PROJECT_DETAILS = "app/CreateProjectPage/PROJECT_DETAILS";
export const IS_CREATED = "app/CreateProjectPage/IS_CREATED";
