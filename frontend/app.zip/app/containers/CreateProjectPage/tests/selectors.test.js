// import { selectCreateProjectPageDomain } from '../selectors';

describe("selectCreateProjectPageDomain", () => {
  it("Expect to have unit tests specified", () => {
    expect(true).toEqual(false);
  });
});
