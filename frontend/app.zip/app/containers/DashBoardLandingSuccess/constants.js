/*
 *
 * DashBoardLandingSuccess constants
 *
 */

export const DEFAULT_ACTION = "app/DashBoardLandingSuccess/DEFAULT_ACTION";
