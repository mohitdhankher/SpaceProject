/*
 *
 * ScenarioList constants
 *
 */

export const DEFAULT_ACTION = "app/ScenarioList/DEFAULT_ACTION";
