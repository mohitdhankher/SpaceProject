// import { selectMarketingPageDomain } from '../selectors';

describe("selectMarketingPageDomain", () => {
  it("Expect to have unit tests specified", () => {
    expect(true).toEqual(false);
  });
});
