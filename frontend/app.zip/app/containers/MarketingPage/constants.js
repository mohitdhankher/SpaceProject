/*
 *
 * MarketingPage constants
 *
 */

export const DEFAULT_ACTION = "app/MarketingPage/DEFAULT_ACTION";
