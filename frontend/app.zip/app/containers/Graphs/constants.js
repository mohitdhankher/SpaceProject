/*
 *
 * Graphs constants
 *
 */

export const DEFAULT_ACTION = "app/Graphs/DEFAULT_ACTION";
