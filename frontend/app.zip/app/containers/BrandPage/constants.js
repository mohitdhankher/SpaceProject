/*
 *
 * BrandPage constants
 *
 */

export const DEFAULT_ACTION = "app/BrandPage/DEFAULT_ACTION";
