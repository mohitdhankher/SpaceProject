// import { selectBrandPageDomain } from '../selectors';

describe("selectBrandPageDomain", () => {
  it("Expect to have unit tests specified", () => {
    expect(true).toEqual(false);
  });
});
