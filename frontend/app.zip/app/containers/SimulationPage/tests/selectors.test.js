// import { selectSimulationPageDomain } from '../selectors';

describe("selectSimulationPageDomain", () => {
  it("Expect to have unit tests specified", () => {
    expect(true).toEqual(false);
  });
});
