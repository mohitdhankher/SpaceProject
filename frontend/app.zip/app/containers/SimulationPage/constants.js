/*
 *
 * SimulationPage constants
 *
 */

export const DEFAULT_ACTION = "app/SimulationPage/DEFAULT_ACTION";
