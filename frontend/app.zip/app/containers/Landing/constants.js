/*
 *
 * Landing constants
 *
 */

export const DEFAULT_ACTION = "app/Landing/DEFAULT_ACTION";
