
/*
 *
 * Dashboard constants
 *
 */

export const DEFAULT_ACTION = "app/NewDashboard/DEFAULT_ACTION";
export const FETCH_TABLEDATA = "app/NewDashboard/FETCH_TABLEDATA";
export const SAVE_TABLEDATA ="app/NewDashboard/SAVE_TABLEDATA";
export const SAVE_SCENARIOKASSANDRA ="app/NewDashboard/SAVE_SCENARIOKASSANDRA";
export const SAVE_SCENARIO = "app/NewDashboard/SAVE_SCENE";
export const TOGGLE_TABLEDATA = "app/NewDashboard/TOGGLE_TABLEDATA"
export const GET_USERINFO = "app/NewDashboard/User"