/*
 *
 * LoginPage constants
 *
 */

export const DEFAULT_ACTION = "app/LoginPage/DEFAULT_ACTION";
export const LOGIN_USER = "app/LoginPage/LOGIN_USER";
export  const SAVE_SCENARIOSTRING =  "app/LoginPage/SAVE_SCENARIOSTRING";
export const EMAIL = "app/LoginPage/EMAIL"
export const PASSWORD = "app/LoginPage/PASSWORD";
