/*
 *
 * Scenarios constants
 *
 */

export const DEFAULT_ACTION = "app/Scenarios/DEFAULT_ACTION";
export const GET_SCENARIOS = "app/Scenarios/GET_SCENARIOS";
export  const GOT_SCENARIOS = "app/Scenarios/GOT_SCENARIOS";