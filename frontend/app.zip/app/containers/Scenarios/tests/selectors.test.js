// import { selectScenariosDomain } from '../selectors';

describe("selectScenariosDomain", () => {
  it("Expect to have unit tests specified", () => {
    expect(true).toEqual(false);
  });
});
